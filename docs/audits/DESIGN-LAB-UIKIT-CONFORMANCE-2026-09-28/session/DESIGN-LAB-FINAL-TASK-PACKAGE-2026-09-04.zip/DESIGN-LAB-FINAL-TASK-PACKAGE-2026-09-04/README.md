# DESIGN-LAB 最终任务包 v1.4

日期：2026-09-04

建议阅读顺序：

1. `DESIGN-LAB-TODAY-EXECUTION-TASKPACK-2026-09-04.md`：唯一人工执行入口。
2. `DESIGN-LAB-TODAY-JOB-LEDGER-2026-09-04.yaml`：机器派工、阻断状态和依赖关系。
3. `DESIGN-LAB-COMPLETE-REPAIR-AND-MIGRATION-PLAN-2026-09-04.md`：完整修复、仓库规范和语言迁移方案。
4. `DESIGN-LAB-HISTORY-TASK-ID-CROSSWALK-2026-09-04.csv`：历史任务 occurrence 与当前任务映射。
5. `DESIGN-LAB-HISTORY-EVIDENCE-MANIFEST-2026-09-04.csv`：历史文件证据基线。
6. `SHA256SUMS.txt`：文件完整性校验值。

当前状态：任务包与历史映射已完成并通过一致性验收；代码实施尚未开始。必须先完成 Coordinator Preflight，之后只派发 Wave 0 的 8 个任务，其余 50 个任务保持 `REGISTER_ONLY`。

关键规模：58 个现行任务、38 个 PR 切片、1,450 条历史 occurrence、527 个历史原始 ID、774 个来源限定实体、178 个碰撞 ID。

